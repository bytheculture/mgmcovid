<template>
	<div class="content p-0">
		<div class="login-wrapper">
			<div class="row m-0">
				<div class="col-lg-4 side-banner" style="background-image:url('/static/images/bg-login.jpg');background-position: center center; background-size: cover;">
					<div class="content px-5 text-center d-flex justify-content-center h-100">
						<div class="align-self-center">
							<img src="/static/images/logo-white.png" width="150" class="mb-4" alt="">
							<h4 class="text-white">Discover great places in world</h4>
							<p class="text-white">Find awesome places, bars, restaurants and activities in London</p>
							<a href="JavaScript:Void(0)" class="btn btn-success">Search Now</a>
						</div>
					</div>
				</div>
				<div class="col-lg-8 site-content">
					<div class="content">
						<div class="row">
							<div class="col-lg-6 mx-auto">
								<div class="text-center mb-4">
									<h2>Sign in to DirectView.</h2>
									<p>Fill up the following details</p>
								</div>
								<div class="card bg-secondary shadow border-0">
									<div class="card-header bg-white pb-5">
										<div class="text-muted text-center mb-3">
											<h6>Sign in with</h6>
										</div>
										<div class="btn-wrapper text-center">
											<a href="#" class="btn btn-neutral btn-icon">
												<span class="btn-inner--icon">
													<i class="fa fa-facebook"></i>
												</span>
												<span class="btn-inner--text">Facebook</span>
											</a>
											<a href="#" class="btn btn-neutral btn-icon">
												<span class="btn-inner--icon">
													<i class="fa fa-google"></i>
												</span>
												<span class="btn-inner--text">Google</span>
											</a>
										</div>
									</div>
									<div class="card-body px-lg-5 py-lg-5">
										<div class="text-center text-muted mb-4">
											<h6>Or sign in with credentials</h6>
										</div>
										<form role="form">
											<div class="form-group mb-3">
												<div class="input-group input-group-alternative">
													<div class="input-group-prepend">
														<span class="input-group-text"><i class="fa fa-envelope"></i></span>
													</div>
													<input class="form-control" placeholder="Email" type="email">
												</div>
											</div>
											<div class="form-group">
												<div class="input-group input-group-alternative">
													<div class="input-group-prepend">
														<span class="input-group-text"><i class="fa fa-unlock-alt"></i></span>
													</div>
													<input class="form-control" placeholder="Password" type="password">
												</div>
											</div>
											<div class="custom-control custom-control-alternative custom-checkbox">
												<input class="custom-control-input" id=" customCheckLogin2" type="checkbox">
												<label class="custom-control-label" for=" customCheckLogin2">
													<span>Remember me</span>
												</label>
											</div>
											<div class="text-center">
												<button type="button" class="btn btn-primary mt-4">Sign in</button>
											</div>
										</form>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
export default {

};
</script>
