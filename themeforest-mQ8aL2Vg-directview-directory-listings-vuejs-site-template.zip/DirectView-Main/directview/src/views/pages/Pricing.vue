<template>
	<div class="main-wrapper">
		<title-bar title="Plans & Pricing" subtitle="Most Affordable Prices"></title-bar>
		<div class="content">
			<div class="container">
				<div class="pricing-n-plan">
					<div class="col-lg-8 mx-auto pb-5 text-center">
						<p class="lead">Pick a plan and start your DirectView experience today.Can’t decide which plan you need? Find the optimal plan for your needs.</p>
					</div>
					<div class="row">
						<div class="col-lg-4 mb-4">
							<div class="card">
								<div class="pricing-wrapper text-center">
									<div class="bg-primary py-5 px-4">
										<h2 class="text-white">Individual</h2>
										<p class="text-white mb-0">Best way for anyone to get started with DirectView</p>
									</div>
									<div class="p-4">
										<h3 class="text-primary mb-0">$32/month</h3>
									</div>
									<div class="bg-secondary p-4">
										<ul class="pricing-listing p-0 m-0">
											<li>​Unlimited Listing</li><li>​Free discount coupon per month</li><li>​Pre-Launch Info</li><li>​Priority support</li><li>Discount on every Bookng</li><li>Custom splash screen</li><li>Partners network</li><li>$7 per service</li>
										</ul>
									</div>
									<div>
										<div class="p-4"> <a href="#" class="btn btn-1 btn-outline-primary">Choose Plan </a></div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-lg-4 mb-4">
							<div class="card">
								<div class="pricing-wrapper text-center">
									<div class="bg-success py-5 px-4">
										<h2 class="text-white">Professional</h2>
										<p class="text-white mb-0">Best way for anyone to get started with DirectView</p>
									</div>
									<div class="p-4">
										<h3 class="text-success mb-0">$50/month</h3>
									</div>
									<div class="bg-secondary p-4">
										<ul class="pricing-listing p-0 m-0">
											<li>​Unlimited Listing</li>
											<li>​Free discount coupon per month</li>
											<li>​Pre-Launch Info</li>
											<li>​Priority support</li>
											<li>Discount on every Bookng</li>
											<li>Custom splash screen</li>
											<li>Partners network</li>
											<li>$7 per service</li>
										</ul>
									</div>
									<div>
										<div class="p-4"> <a href="#" class="btn btn-1 btn-outline-success">Choose Plan </a></div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-lg-4 mb-4">
							<div class="card">
								<div class="pricing-wrapper text-center">
									<div class="bg-info py-5 px-4">
										<h2 class="text-white">Business</h2>
										<p class="text-white mb-0">Best way for anyone to get started with DirectView</p>
									</div>
									<div class="p-4">
										<h3 class="text-info mb-0">$99/month</h3>
									</div>
									<div class="bg-secondary p-4">
										<ul class="pricing-listing p-0 m-0">
											<li>​Unlimited Listing</li>
											<li>​Free discount coupon per month</li>
											<li>​Pre-Launch Info</li>
											<li>​Priority support</li>
											<li>Discount on every Bookng</li>
											<li>Custom splash screen</li>
											<li>Partners network</li>
											<li>$7 per service</li>
										</ul>
									</div>
									<div>
										<div class="p-4"> <a href="#" class="btn btn-1 btn-outline-info">Choose Plan </a></div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>
import TitleBar from 'Components/globalFrontendComponents/TitleBar';
export default {
	components: {
		TitleBar: TitleBar
	}
};
</script>
