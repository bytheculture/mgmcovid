<template>
	<div class="main-wrapper">
	   <title-bar title="Contact Us" subtitle="Explore your search places"></title-bar>
	   <div class="content">
	      <div class="container">
	         <div class="contact-wrapper">
	            <div class="block-space pt-0">
	            <div class="row">
	               <div class="col-lg-7 mb-4">
	                  <h2>Stay Contact Us</h2>
	                  <p class="lead">Get in touch and let us know how we can help. Fill out the form and we’ll be in touch as
	                     soon as possible.</p>
	               </div>
	            </div>
	            <div class="contact-form-wrapper">
	               <div class="row">
	                  <div class="col-lg-6">
	                     <div class="form-group mb-4">
	                        <div class="input-group input-group-alternative">
	                           <div class="input-group-prepend">
	                              <span class="input-group-text"><i class="ni ni-user-run"></i></span>
	                           </div>
	                           <input class="form-control" placeholder="First Name" type="text">
	                        </div>
	                     </div>
	                  </div>
	                  <div class="col-lg-6">
	                     <div class="form-group mb-4">
	                        <div class="input-group input-group-alternative">
	                           <div class="input-group-prepend">
	                              <span class="input-group-text"><i class="ni ni-user-run"></i></span>
	                           </div>
	                           <input class="form-control" placeholder="Last Name" type="text">
	                        </div>
	                     </div>
	                  </div>
	                  <div class="col-lg-6">
	                     <div class="form-group mb-4">
	                        <div class="input-group input-group-alternative">
	                           <div class="input-group-prepend">
	                              <span class="input-group-text"><i class="ni ni-email-83"></i></span>
	                           </div>
	                           <input class="form-control" placeholder="Email address" type="email">
	                        </div>
	                     </div>
	                  </div>
	                  <div class="col-lg-6">
	                     <div class="form-group mb-4">
	                        <div class="input-group input-group-alternative">
	                           <div class="input-group-prepend">
	                              <span class="input-group-text"><i class="ni ni-user-run"></i></span>
	                           </div>
	                           <input class="form-control" placeholder="Subject" type="text">
	                        </div>
	                     </div>
	                  </div>
	               </div>
	               <div class="form-group mb-4">
	                  <textarea class="form-control form-control-alternative" name="name" rows="4" cols="80" placeholder="Type a message..."></textarea>
	               </div>
	               <div>
	                  <button type="button" class="btn btn-primary btn-round btn-block btn-lg">Send Message</button>
	               </div>
	            </div>
	         </div>
	         </div>
	      </div>
	      <div class="bg-secondary">
            <section class="block-space contact-info">
                  <div class="container">
                     <div class="row align-items-center">
                        <div class="col-lg-4 col-md-12 mb-4">
                           <div class="contact-media"> <i class="fa fa-map-marker"></i><span>Address:</span>
                              <p>423B, Road Wordwide Country, USA</p>
                           </div>
                        </div>
                        <div class="col-lg-4 col-md-6 mb-4">
                           <div class="contact-media"> <i class="fa fa-envelope"></i><span>Email Address</span><a href="#">
                                 htinfotech7@gmail.com</a>
                           </div>
                        </div>
                        <div class="col-lg-4 col-md-6 mb-4">
                           <div class="contact-media"> <i class="fa fa-phone"></i><span>Phone Number</span><a href="#">+01-1234-567-8900</a>
                           </div>
                        </div>
                     </div>
                  </div>
               </section>
	      </div>   
	   </div>
	</div>
</template>

<script>
import TitleBar from 'Components/globalFrontendComponents/TitleBar';
export default {
	components: {
		TitleBar: TitleBar
	}
};
</script>
