<template>
	<div class="main-wrapper">
		<!--Title Bar -->
		<title-bar title="Blog Listing" subtitle="Explore your search places"></title-bar>
   	<!-- Content -->
	   <div class="content">
         <div class="container">
            <!-- Blog Posts -->
            <div class="blog-page">
               <div class="row">
                  <div class="col-lg-9 col-md-8 padding-right-30">
                     <!-- Blog Post -->
                     <div class="card card-lift--hover shadow border-0 mb-4">
                        <img alt="" class="img-fluid" src="/static/images/dp-3.jpg">
                        <div class="card-body py-4">
                           <h5 class="text-primary">Take a Look at Hotels for All Budgets</h5>
                           <p class="text-primary">22 August 2018</p>
                           <p class="description mt-3">Sed sed tristique nibh iam porta volutpat finibus. Donec in aliquet urneget mattis lorem. Pellentesque pellentesque</p>
                           <router-link class="btn btn-primary" to='/pages/blog/detail'>Read More</router-link>
                        </div>
                     </div>
                     <div class="card card-lift--hover shadow border-0 mb-4">
                           <img alt="" class="img-fluid" src="/static/images/dp-4.jpg">
                        <div class="card-body py-4">
                           <h5 class="text-primary">Take a Look at Hotels for All Budgets</h5>
                           <p class="text-primary">22 August 2018</p>
                           <p class="description mt-3">Sed sed tristique nibh iam porta volutpat finibus. Donec in aliquet urneget mattis lorem. Pellentesque pellentesque</p>
                           <router-link class="btn btn-primary" to='/pages/blog/detail'>Read More</router-link>
                        </div>
                     </div>
                     <div class="card card-lift--hover shadow border-0 mb-4">
                           <img alt="" class="img-fluid" src="/static/images/dp-2.jpg">
                        <div class="card-body py-4">
                           <h5 class="text-primary">Take a Look at Hotels for All Budgets</h5>
                           <p class="text-primary">22 August 2018</p>
                           <p class="description mt-3">Sed sed tristique nibh iam porta volutpat finibus. Donec in aliquet urneget mattis lorem. Pellentesque pellentesque</p>
                           <router-link class="btn btn-primary" to='/pages/blog/detail'>Read More</router-link>
                        </div>
                     </div>
                  </div>
                  <!-- Blog Posts / End -->
                  <!-- Widgets -->
                  <div class="col-lg-3 col-md-4">
                     <div class="sidebar right">
                        <!-- Widget -->
                        <div class="widget">
                              <div class="form-group">
                                    <div class="input-group mb-4">
                                      <div class="input-group-prepend">
                                        <span class="input-group-text"><i class="fa fa-search"></i></span>
                                      </div>
                                      <input class="form-control" placeholder="Search" type="text">
                                    </div>
                                  </div>
                        </div>
                        <!-- Widget / End -->
                        <!-- Widget -->
                    
                        <!-- Widget / End -->
                        <!-- Widget -->
                        <div class="widget margin-top-40">
                           <h3>Popular Posts</h3>
                           <ul class="widget-tabs">
                              <!-- Post #1 -->
                              <li>
                                 <div class="widget-content">
                                    <div class="widget-thumb">
                                       <router-link to='/pages/blog/detail'><img src="/static/images/bw-1.jpg" alt=""></router-link>
                                    </div>
                                    <div class="widget-text">
                                       <h5><a >Hotels for All Budgets </a></h5>
                                       <span>October 26, 2016</span>
                                    </div>
                                    <div class="clearfix"></div>
                                 </div>
                              </li>
                              <!-- Post #2 -->
                              <li>
                                 <div class="widget-content">
                                    <div class="widget-thumb">
                                       <router-link to='/pages/blog/detail'><img src="/static/images/bw-2.jpg" alt=""></router-link>
                                    </div>
                                    <div class="widget-text">
                                       <h5><router-link to='/pages/blog/detail'>The 50 Greatest Street Arts In London</router-link></h5>
                                       <span>November 9, 2016</span>
                                    </div>
                                    <div class="clearfix"></div>
                                 </div>
                              </li>
                              <!-- Post #3 -->
                              <li>
                                 <div class="widget-content">
                                    <div class="widget-thumb">
                                       <router-link to='/pages/blog/detail'><img src="/static/images/bw-3.jpg" alt=""></router-link>
                                    </div>
                                    <div class="widget-text">
                                       <h5><router-link to='/pages/blog/detail'>The Best Cofee Shops In Sydney Neighborhoods</router-link></h5>
                                       <span>November 12, 2016</span>
                                    </div>
                                    <div class="clearfix"></div>
                                 </div>
                              </li>
                           </ul>
                        </div>
                        <!-- Widget / End-->
                        <!-- Widget -->
                        <div class="widget margin-top-40">
                           <h3 class="margin-bottom-25">Social</h3>
                           <div class="btn-wrapper">
                              <a target="_blank" href="#" class="btn btn-neutral btn-icon-only btn-twitter btn-round btn-lg" data-toggle="tooltip" data-original-title="Follow us">
                              <i class="fa fa-twitter"></i>
                              </a>
                              <a target="_blank" href="#" class="btn btn-neutral btn-icon-only btn-facebook btn-round btn-lg" data-toggle="tooltip" data-original-title="Like us">
                              <i class="fa fa-facebook-square"></i>
                              </a>
                              <a target="_blank" href="#" class="btn btn-neutral btn-icon-only btn-dribbble btn-lg btn-round" data-toggle="tooltip" data-original-title="Follow us">
                              <i class="fa fa-dribbble"></i>
                              </a>
                              <a target="_blank" href="#" class="btn btn-neutral btn-icon-only btn-github btn-round btn-lg" data-toggle="tooltip" data-original-title="Star on Github">
                              <i class="fa fa-github"></i>
                              </a>
                           </div>
                        </div>
                        <!-- Widget / End-->
                        <div class="clearfix"></div>
                        <div class="margin-bottom-40"></div>
                     </div>
                  </div>
               </div>
               <!-- Sidebar / End -->
            </div>
         </div>
	   </div>
	</div>
</template>

<script>
import TitleBar from 'Components/globalFrontendComponents/TitleBar';
export default {
	components: {
		TitleBar: TitleBar
	}
};
</script>
