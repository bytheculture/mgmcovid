<template>
   <div class="main-wrapper">
      <!--Title Bar -->
      <title-bar title="Blog Detail" subtitle="Explore your search places"></title-bar>
 <!-- Content -->
 <div class="content">


 <div class="container">
    <!-- Blog Posts -->
    <div class="blog-page">
       <div class="row">
          <!-- Post Content -->
          <div class="col-lg-9 col-md-8 padding-right-30">
             <!-- Blog Post -->
             <div class="blog-post single-post">
                <!-- Img -->
                <img class="post-img img-fluid" src="/static/images/dp-3.jpg" alt="">
                <!-- Content -->
                <div class="post-content">
                   <h3>The 50 Greatest Street Arts In London</h3>
                   <ul class="post-meta">
                      <li>August 22, 2017</li>
                      <li><a >Tips</a></li>
                      <li><a >5 Comments</a></li>
                   </ul>
                   <p>Nam nisl lacus, dignissim ac tristique ut, scelerisque eu massa. Vestibulum ligula nunc, rutrum in malesuada vitae, tempus sed augue. Curabitur quis lectus quis augue dapibus facilisis. Vivamus tincidunt orci est, in vehicula nisi eleifend ut. Vestibulum sagittis varius orci vitae.</p>
                   <div class="post-quote">
                      <span class="icon"></span>
                      <blockquote>
                         Mauris aliquet ultricies ante, non faucibus ante gravida sed. Sed ultrices pellentesque purus, vulputate volutpat ipsum hendrerit sed neque sed sapien rutrum.
                      </blockquote>
                   </div>
                   <p>In ut odio libero, at vulputate urna. Nulla tristique mi a massa convallis cursus. Nulla eu mi magna. Etiam suscipit commodo gravida. Cras suscipit, quam vitae adipiscing faucibus, risus nibh laoreet odio, a porttitor metus eros ut enim. Morbi augue velit, tempus mattis dignissim nec, porta sed risus. Donec eget magna eu lorem tristique pellentesque eget eu dui. Fusce lacinia tempor malesuada. Ut lacus sapien, placerat a ornare nec, elementum sit amet felis. Maecenas pretium lorem hendrerit eros sagittis fermentum.</p>
                   <p>Phasellus enim magna, varius et commodo ut, ultricies vitae velit. Ut nulla tellus, eleifend euismod pellentesque vel, sagittis vel justo. In libero urna, venenatis sit amet ornare non, suscipit nec risus. Sed consequat justo non mauris pretium at tempor justo sodales. Quisque tincidunt laoreet malesuada. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Integer vitae ante enim. Fusce sed elit est. Suspendisse sit amet mauris in quam pretium faucibus et aliquam odio. </p>
                </div>
             </div>
             <!-- Blog Post / End -->
             <!-- Post Navigation -->
             <ul id="posts-nav" class="margin-top-0 margin-bottom-45">
                <li class="next-post">
                   <button class="btn btn-1 btn-primary" type="button">Next</button>
                </li>
                <li class="prev-post">
                   <button class="btn btn-1 btn-primary" type="button"> Previous</button>
                </li>
             </ul>
             <!-- About Author -->
             <div class="about-author">
                <img src="/static/images/thumb-4.jpg" alt="" />
                <div class="about-description">
                   <h4>Ethan Moore</h4>
                   <p>Nullam ultricies, velit ut varius molestie, ante metus condimentum nisi, dignissim facilisis turpis ex in libero. Sed porta ante tortor, a pulvinar mi facilisis nec. Proin finibus dolor ac convallis congue.</p>
                </div>
             </div>
             <div class="margin-top-50"></div>
             <!-- Reviews -->
             <section class="comments">
                <h4 class="headline margin-bottom-35">Comments <span class="comments-amount">(5)</span></h4>
                <div class="row py-4 list-img-wrap">
                   <div class="col-md-2 list-img"><img class="img-fluid rounded-circle shadow-lg" src="/static/images/thumb-1.jpg"></div>
                   <div class="col-md-10">
                      <h5 class="text-primary"> Loreta Lavine </h5>
                      <p class="text-muted">15 Minutes Ago</p>
                      <p>Lorem Ipsum is simply dummy text of the pr make but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                      <button class="btn btn-sm btn-primary" type="button">Reply</button>
                   </div>
                </div>
                <div class="row py-4 list-img-wrap">
                   <div class="col-md-2 list-img"><img class="img-fluid rounded-circle shadow-lg" src="/static/images/thumb-2.jpg"></div>
                   <div class="col-md-10">
                      <h5 class="text-primary"> Kena Delatte </h5>
                      <p class="text-muted">2 Days Ago</p>
                      <p>Suspendisse enim nibh, ultricies id elit et, fermentum pellentesque neque. Curabitur at nibh finibus, facilisis lectus eu, ornare nulla. Morbi venenatis ex id diam laoreet vulputate</p>
                      <button class="btn btn-sm btn-primary" type="button">Reply</button>
                   </div>
                </div>
                <div class="row py-4 list-img-wrap">
                   <div class="col-md-2 list-img"><img class="img-fluid rounded-circle shadow-lg" src="/static/images/thumb-3.jpg"></div>
                   <div class="col-md-10">
                      <h5 class="text-primary"> Hilda Oatman </h5>
                      <p class="text-muted">3 Days Ago</p>
                      <p>Proin rhoncus nulla dictum, volutpat sem sed, aliquam nisi. Sed lorem turpis, viverra eu lacinia id, pellentesque et mi. Quisque vitae tortor dui. Nullam ac eros tempus erat vulputate ultrices ac sed dui. Quisque malesuada lacus non est fringilla, vitae finibus magna rutrum.</p>
                      <button class="btn btn-sm btn-primary" type="button">Reply</button>
                   </div>
                </div>
             </section>
             <div class="clearfix"></div>
             <!-- Add Comment -->
             <div id="add-review" class="add-review-box mt-4">
                <!-- Add Review -->
                <h3 class="listing-desc-headline mb-4">Add Review</h3>
                <!-- Review Comment -->
                <form id="add-comment" class="add-comment">
                   <fieldset>
                      <div class="row">
                         <div class="col-md-6">
                              <div class="form-group">
                                    <input type="text" placeholder="Name" class="form-control form-control-alternative">
                                  </div>
                         </div>
                         <div class="col-md-6">
                              <div class="form-group">
                                    <input type="email" placeholder="Email" class="form-control form-control-alternative">
                                  </div>
                         </div>
                         <div class="col-md-12">
                              <div class="form-group">
                                    <input type="text" placeholder="Subject" class="form-control form-control-alternative">
                                  </div>
                         </div>
                      </div>
                      <div class="">
                           <div class="form-group">
                                
                                 <textarea class="form-control form-control-alternative" placeholder="Comment" id="exampleFormControlTextarea1" rows="3"></textarea>
                               </div>
                      </div>
                   </fieldset>
                   <button class="mt-4 btn btn-primary">Submit Comment</button>
                   <div class="clearfix"></div>
                </form>
             </div>
             <!-- Add Review Box / End -->
          </div>
          <!-- Content / End -->
          <!-- Widgets -->
          <div class="col-lg-3 col-md-4">
             <div class="sidebar right">
                <!-- Widget -->
                <div class="widget">
                   <h3 class="margin-top-0 margin-bottom-25">Search Blog</h3>
                   <div class="form-group">
                      <div class="input-group mb-4">
                         <div class="input-group-prepend">
                            <span class="input-group-text"><i class="fa fa-search"></i></span>
                         </div>
                         <input class="form-control" placeholder="Search" type="text">
                      </div>
                   </div>
                </div>
                <!-- Widget / End -->
                <!-- Widget -->
                <div class="widget mb-4">
                   <h3>Popular Posts</h3>
                   <ul class="widget-tabs">
                      <!-- Post #1 -->
                      <li>
                         <div class="widget-content">
                            <div class="widget-thumb">
                               <a><img src="/static/images/bw-1.jpg" alt=""></a>
                            </div>
                            <div class="widget-text">
                               <h5><a >Hotels for All Budgets </a></h5>
                               <span>October 26, 2016</span>
                            </div>
                            <div class="clearfix"></div>
                         </div>
                      </li>
                      <!-- Post #2 -->
                      <li>
                         <div class="widget-content">
                            <div class="widget-thumb">
                               <a ><img src="/static/images/bw-2.jpg" alt=""></a>
                            </div>
                            <div class="widget-text">
                               <h5><a>The 50 Greatest Street Arts In London</a></h5>
                               <span>November 9, 2016</span>
                            </div>
                            <div class="clearfix"></div>
                         </div>
                      </li>
                      <!-- Post #3 -->
                      <li>
                         <div class="widget-content">
                            <div class="widget-thumb">
                               <a ><img src="/static/images/bw-3.jpg" alt=""></a>
                            </div>
                            <div class="widget-text">
                               <h5><a>The Best Cofee Shops In Sydney Neighborhoods</a></h5>
                               <span>November 12, 2016</span>
                            </div>
                            <div class="clearfix"></div>
                         </div>
                      </li>
                   </ul>
                </div>
                <!-- Widget / End-->
                <!-- Widget -->
                <div class="widget margin-top-40">
                   <h3 class="margin-bottom-25">Follow Us</h3>
                   <div class=" btn-wrapper">
                      <a target="_blank" href="https://twitter.com" class="btn btn-neutral btn-icon-only btn-twitter btn-round btn-lg" data-toggle="tooltip" data-original-title="Follow us">
                      <i class="fa fa-twitter"></i>
                      </a>
                      <a target="_blank" href="https://www.facebook.com" class="btn btn-neutral btn-icon-only btn-facebook btn-round btn-lg" data-toggle="tooltip" data-original-title="Like us">
                      <i class="fa fa-facebook-square"></i>
                      </a>
                      <a target="_blank" href="https://dribbble.com" class="btn btn-neutral btn-icon-only btn-dribbble btn-lg btn-round" data-toggle="tooltip" data-original-title="Follow us">
                      <i class="fa fa-dribbble"></i>
                      </a>
                      <a target="_blank" href="https://github.com" class="btn btn-neutral btn-icon-only btn-github btn-round btn-lg" data-toggle="tooltip" data-original-title="Star on Github">
                      <i class="fa fa-github"></i>
                      </a>
                   </div>
                </div>
                <!-- Widget / End-->
                <div class="clearfix"></div>
                <div class="margin-bottom-40"></div>
             </div>
          </div>
       </div>
       <!-- Sidebar / End -->
    </div>
 </div>
</div>
</div>
</template>

<script>
import TitleBar from 'Components/globalFrontendComponents/TitleBar';
export default {
	components: {
		TitleBar: TitleBar
	}
};
</script>
