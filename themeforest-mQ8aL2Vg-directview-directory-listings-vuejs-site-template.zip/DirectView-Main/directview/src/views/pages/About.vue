<template>
	<div class="main-wrapper">
   <title-bar title="About Us" subtitle="Explore your search places"></title-bar>
   <div class="content pt-0">
      <div class="about-wrapper">
         <div class="block-space">
               <div class="container">
            <div class="row">
               <div class="col-lg-6 col-md-10 ml-auto mr-auto">
                  <div class="section-title text-center mb-5">
                     <h2>Three Simple Step To Started Working Process</h2>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-lg-4 col-md-12 mb-4">
                  <div class="about-info">
                     <div class="about-num-box">
                        <div class="about-icon">
                           <span><i class="fa fa-bookmark"></i></span>
                        </div>
                        <div class="about-highlight">01</div>
                     </div>
                     <div class="about-desc">
                        <h4>Plan</h4>
                        <p class="mb-0">Nostrud exercitat ullamco lorem ipsum dolor sit amet, consece adipising elit,
                           sed
                           doeo eiusmod</p>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4 col-md-12 mb-4">
                  <div class="about-info">
                     <div class="about-num-box">
                        <div class="about-icon">
                           <span><i class="fa fa-rocket"></i></span>
                        </div>
                        <div class="about-highlight">02</div>
                     </div>
                     <div class="about-desc">
                        <h4>Code</h4>
                        <p class="mb-0">Nostrud exercitat ullamco lorem ipsum dolor sit amet, consece adipising elit,
                           sed
                           doeo eiusmod</p>
                     </div>
                  </div>
               </div>
               <div class="col-lg-4 col-md-12 md-mt-5 mb-4">
                  <div class="about-info">
                     <div class="about-num-box">
                        <div class="about-icon">
                           <span><i class="fa fa-check"></i></span>
                        </div>
                        <div class="about-highlight">03</div>
                     </div>
                     <div class="about-desc">
                        <h4>Deliver</h4>
                        <p class="mb-0">Nostrud exercitat ullamco lorem ipsum dolor sit amet, consece adipising elit,
                           sed
                           doeo eiusmod</p>
                     </div>
                  </div>
               </div>
            </div>
            </div>
         </div>
         <div class="block-space bg-secondary">
               <div class="container">
            <div class="row row-grid align-items-center">
               <div class="col-md-6">
                  <div class="card bg-default shadow border-0">
                     <img src="/static/images/about-image.jpg" class="card-img-top">
                     <blockquote class="card-blockquote">
                        <svg preserveAspectRatio="none" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 583 95" class="svg-bg">
                           <polygon points="0,52 583,95 0,95" class="fill-default"></polygon>
                           <polygon points="0,42 583,95 683,0 0,95" opacity=".2" class="fill-default"></polygon>
                        </svg>
                        <h4 class="display-3 font-weight-bold text-white">Our Goal</h4>
                        <p class="lead text-italic text-white">Lorem ipsum, dolor sit amet consectetur adipisicing
                           elit.
                           Vel consectetur, ipsa autem vitae quos ea laborum expedita </p>
                     </blockquote>
                  </div>
               </div>
               <div class="col-md-6">
                  <div class="pl-md-5">
                     <div class="icon icon-lg icon-shape icon-shape-warning shadow rounded-circle mb-5">
                        <i class="fa fa-info"></i>
                     </div>
                     <h3>About Us</h3>
                     <p class="lead">Lorem ipsum dolor sit amet consectetur adipisicing elit. Exercitationem sapiente,
                        fugiat commodi reprehenderit expedita nam nemo</p>
                     <p> Molestiae labore inventore dolor voluptatem iste voluptatum sed iusto, pariatur doloremque quo
                        nesciunt sit!</p>
                     <p> Molestiae labore inventore dolor voluptatem iste voluptatum sed iusto, pariatur doloremque quo
                        nesciunt sit!</p>
                     <a href="#" class="font-weight-bold text-warning mt-5">Explore Your Places</a>
                  </div>
               </div>
            </div>
            </div>
         </div>
         <!-- Team Section -->
         <team :title="teamSectionTitle" :desc="teamSectionDesc" :data="teamMembers"></team>
         <div class="">
            <div class="container">
               <div class="card bg-gradient-warning shadow-lg border-0">
                  <div class="p-5">
                     <div class="row align-items-center">
                        <div class="col-lg-8">
                           <h3 class="text-white"> Lorem ipsum dolor sit amet consectetur</h3>
                           <p class="lead text-white mt-3"> adipisicing elit. Quos, consectetur ex? Amet facere neque,
                              eaque accusamus cumque, commodi fugit, provident</p>
                        </div>
                        <div class="col-lg-3 ml-lg-auto">
                           <a href="#" class="btn btn-lg btn-block btn-white">Start Now</a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
</template>

<script>
import Team from 'Components/globalFrontendComponents/Team';
import TitleBar from 'Components/globalFrontendComponents/TitleBar';
export default {
	data(){
		return{
			teamSectionTitle :'The Amazing Team',
   		teamSectionDesc  :'According to the National Oceanic and Atmospheric Administration, Ted, Scambos, NSIDClead scentist, puts the potentially record maximum.',
   		teamMembers : [
                     {
                        name     : 'Ryan Tompson',
                        position : 'Web Developer',
                        image    : '/static/images/thumb-1.jpg'
                     },
                     {
                        name     : 'Romina Hadid',
                        position : 'Marketing Strategist',
                        image    : '/static/images/thumb-2.jpg'
                     },
                     {
                        name     : 'Alexander Smith',
                        position : 'UI/UX Designer',
                        image    : '/static/images/thumb-3.jpg'
                     },
                     {
                        name     : 'Ethan Moore',
                        position : 'Founder and CEO',
                        image    : '/static/images/thumb-4.jpg'
                     }
                    
                  ]
		}
	},
	components: {
		Team: Team,
		TitleBar: TitleBar
	}
};
</script>
